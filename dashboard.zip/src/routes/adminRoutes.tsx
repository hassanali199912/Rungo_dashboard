import { lazy } from "react";
import type { RouteObject } from "react-router-dom";
import AdminShell from "../layout/admin/AdminShell";
import AppError from "../features/public/pages/error/AppError";
import ProtectedRoute from "./ProtectedRoute";

const AdminOverview = lazy(() => import("../features/admin/pages/overview/AdminOverview"));
const Instructors = lazy(() => import("../features/admin/pages/instructors/Instructors"));
const InstructorDetail = lazy(() => import("../features/admin/pages/instructors/InstructorDetail"));
const Students = lazy(() => import("../features/admin/pages/students/Students"));
const StudentDetail = lazy(() => import("../features/admin/pages/students/StudentDetail"));
const AdminCourses = lazy(() => import("../features/admin/pages/courses/AdminCourses"));
const AdminCourseDetail = lazy(() => import("../features/admin/pages/courses/AdminCourseDetail"));
const AdminShorts = lazy(() => import("../features/admin/pages/shorts/AdminShorts"));
const AdminSubscriptions = lazy(() => import("../features/admin/pages/subscriptions/AdminSubscriptions"));
const AdminAssistants = lazy(() => import("../features/admin/pages/assistants/AdminAssistants"));
const AdminInvoices = lazy(() => import("../features/admin/pages/invoices/AdminInvoices"));
const AdminSettings = lazy(() => import("../features/admin/pages/settings/AdminSettings"));

const adminRoutes: RouteObject[] = [
    {
        path: "/admin",
        element: (
            <ProtectedRoute allow="staff">
                <AdminShell />
            </ProtectedRoute>
        ),
        errorElement: <AppError />,
        children: [
            { index: true, element: <AdminOverview /> },
            { path: "instructors", element: <Instructors /> },
            { path: "instructors/:id", element: <InstructorDetail /> },
            { path: "students", element: <Students /> },
            { path: "students/:id", element: <StudentDetail /> },
            { path: "courses", element: <AdminCourses /> },
            { path: "courses/:id", element: <AdminCourseDetail /> },
            { path: "shorts", element: <AdminShorts /> },
            { path: "subscriptions", element: <AdminSubscriptions /> },
            {
                path: "assistants",
                element: (
                    <ProtectedRoute allow="admin">
                        <AdminAssistants />
                    </ProtectedRoute>
                ),
            },
            {
                path: "invoices",
                element: (
                    <ProtectedRoute allow="admin">
                        <AdminInvoices />
                    </ProtectedRoute>
                ),
            },
            { path: "settings", element: <AdminSettings /> },
        ],
    },
];

export default adminRoutes;
